using Npgsql;

namespace Bai1_LoginForm;

internal static class Database
{
    // Sua YOUR_POSTGRES_PASSWORD thanh mat khau Postgre/MySQL tren may thay.
    internal const string ConnectionString =
        "Host=localhost;Port=5432;Database=LoginDB;Username=postgres;Password=Nhat@2006";

    internal static NpgsqlConnection CreateConnection() => new(ConnectionString);
}
