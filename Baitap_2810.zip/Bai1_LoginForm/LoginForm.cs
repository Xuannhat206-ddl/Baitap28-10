using Npgsql;

namespace Bai1_LoginForm;

public sealed class LoginForm : Form
{
    private readonly TextBox txtUsername = new();
    private readonly TextBox txtPassword = new();
    private readonly CheckBox chkShowPassword = new();
    private readonly Button btnLogin = new();
    private readonly Button btnExit = new();
    private readonly ErrorProvider errorProvider = new();

    public LoginForm()
    {
        Text = "Đăng nhập";
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        ClientSize = new Size(390, 235);

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(20),
            ColumnCount = 2,
            RowCount = 5
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 125));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        for (int i = 0; i < 5; i++)
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 20));

        txtUsername.Name = "txtUsername";
        txtUsername.Dock = DockStyle.Fill;

        txtPassword.Name = "txtPassword";
        txtPassword.Dock = DockStyle.Fill;
        txtPassword.UseSystemPasswordChar = true;

        chkShowPassword.Name = "chkShowPassword";
        chkShowPassword.Text = "Hiện mật khẩu";
        chkShowPassword.AutoSize = true;

        btnLogin.Name = "btnLogin";
        btnLogin.Text = "Đăng nhập";
        btnLogin.AutoSize = true;
        btnLogin.Click += BtnLogin_Click;

        btnExit.Name = "btnExit";
        btnExit.Text = "Thoát";
        btnExit.AutoSize = true;
        btnExit.Click += (_, _) => Close();

        chkShowPassword.CheckedChanged += (_, _) =>
            txtPassword.UseSystemPasswordChar = !chkShowPassword.Checked;

        layout.Controls.Add(new Label { Text = "Tên đăng nhập:", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 0);
        layout.Controls.Add(txtUsername, 1, 0);
        layout.Controls.Add(new Label { Text = "Mật khẩu:", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 1);
        layout.Controls.Add(txtPassword, 1, 1);
        layout.Controls.Add(chkShowPassword, 1, 2);

        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true };
        buttons.Controls.Add(btnLogin);
        buttons.Controls.Add(btnExit);
        layout.Controls.Add(buttons, 1, 3);

        Controls.Add(layout);
        AcceptButton = btnLogin;
        CancelButton = btnExit;
        errorProvider.ContainerControl = this;
    }

    private async void BtnLogin_Click(object? sender, EventArgs e)
    {
        errorProvider.Clear();
        bool valid = true;

        if (string.IsNullOrWhiteSpace(txtUsername.Text))
        {
            errorProvider.SetError(txtUsername, "Vui lòng nhập tên đăng nhập.");
            valid = false;
        }

        if (string.IsNullOrWhiteSpace(txtPassword.Text))
        {
            errorProvider.SetError(txtPassword, "Vui lòng nhập mật khẩu.");
            valid = false;
        }

        if (!valid) return;

        btnLogin.Enabled = false;
        try
        {
            await using var conn = Database.CreateConnection();
            await conn.OpenAsync();

            const string sql = """
                SELECT COUNT(*)
                FROM "Users"
                WHERE "Username" = @username AND "Password" = @password;
                """;

            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("username", txtUsername.Text.Trim());
            cmd.Parameters.AddWithValue("password", txtPassword.Text);

            var result = Convert.ToInt64(await cmd.ExecuteScalarAsync());
            if (result > 0)
                MessageBox.Show("Đăng nhập thành công!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("Tên đăng nhập hoặc mật khẩu không đúng.", "Đăng nhập thất bại",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        catch (NpgsqlException ex)
        {
            MessageBox.Show("Không kết nối được PostgreSQL. Hãy kiểm tra PostgreSQL Server và chuỗi kết nối.\n\nChi tiết: " + ex.Message,
                "Lỗi cơ sở dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            btnLogin.Enabled = true;
        }
    }
}
