namespace Bai2_DangKyKhoaHoc;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new RegistrationForm());
    }
}
