using System.Data;
using Npgsql;

namespace Bai2_DangKyKhoaHoc;

public sealed class RegistrationForm : Form
{
    private readonly TextBox txtFullName = new();
    private readonly MaskedTextBox mtxtPhone = new();
    private readonly DateTimePicker dtpBirthDate = new();
    private readonly ComboBox cboCourse = new();
    private readonly RadioButton rdoMale = new();
    private readonly RadioButton rdoFemale = new();
    private readonly CheckBox chkProgramming = new();
    private readonly CheckBox chkSports = new();
    private readonly CheckBox chkMusic = new();
    private readonly Button btnRegister = new();
    private readonly ErrorProvider errorProvider = new();

    public RegistrationForm()
    {
        Text = "Đăng ký khóa học";
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(560, 420);
        MinimumSize = new Size(560, 420);

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(18),
            ColumnCount = 2,
            RowCount = 7,
            AutoScroll = true
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 155));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        for (int i = 0; i < 7; i++)
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));

        txtFullName.Name = "txtFullName";
        txtFullName.Dock = DockStyle.Fill;

        mtxtPhone.Name = "mtxtPhone";
        mtxtPhone.Mask = "0000000000";
        mtxtPhone.Dock = DockStyle.Left;
        mtxtPhone.Width = 180;

        dtpBirthDate.Name = "dtpBirthDate";
        dtpBirthDate.Format = DateTimePickerFormat.Custom;
        dtpBirthDate.CustomFormat = "dd/MM/yyyy";
        dtpBirthDate.Dock = DockStyle.Left;
        dtpBirthDate.Width = 180;

        cboCourse.Name = "cboCourse";
        cboCourse.DropDownStyle = ComboBoxStyle.DropDownList;
        cboCourse.Dock = DockStyle.Fill;
        cboCourse.DisplayMember = "CourseName";
        cboCourse.ValueMember = "CourseId";

        rdoMale.Text = "Nam";
        rdoMale.AutoSize = true;
        rdoMale.Checked = true;
        rdoFemale.Text = "Nữ";
        rdoFemale.AutoSize = true;
        var genderPanel = new FlowLayoutPanel { Dock = DockStyle.Fill };
        genderPanel.Controls.Add(rdoMale);
        genderPanel.Controls.Add(rdoFemale);

        chkProgramming.Text = "Lập trình";
        chkProgramming.AutoSize = true;
        chkSports.Text = "Thể thao";
        chkSports.AutoSize = true;
        chkMusic.Text = "Âm nhạc";
        chkMusic.AutoSize = true;
        var interestPanel = new FlowLayoutPanel { Dock = DockStyle.Fill };
        interestPanel.Controls.Add(chkProgramming);
        interestPanel.Controls.Add(chkSports);
        interestPanel.Controls.Add(chkMusic);

        btnRegister.Name = "btnRegister";
        btnRegister.Text = "Đăng ký";
        btnRegister.AutoSize = true;
        btnRegister.Click += BtnRegister_Click;

        AddRow(layout, "Họ và tên:", txtFullName, 0);
        AddRow(layout, "Số điện thoại:", mtxtPhone, 1);
        AddRow(layout, "Ngày sinh:", dtpBirthDate, 2);
        AddRow(layout, "Khóa học:", cboCourse, 3);
        AddRow(layout, "Giới tính:", genderPanel, 4);
        AddRow(layout, "Sở thích:", interestPanel, 5);
        layout.Controls.Add(btnRegister, 1, 6);

        Controls.Add(layout);
        errorProvider.ContainerControl = this;
        Load += async (_, _) => await LoadCoursesAsync();
    }

    private static void AddRow(TableLayoutPanel layout, string label, Control control, int row)
    {
        layout.Controls.Add(new Label
        {
            Text = label,
            AutoSize = true,
            Anchor = AnchorStyles.Left,
            TextAlign = ContentAlignment.MiddleLeft
        }, 0, row);
        layout.Controls.Add(control, 1, row);
    }

    private async Task LoadCoursesAsync()
    {
        try
        {
            var table = new DataTable();
            await using var conn = Database.CreateConnection();
            await conn.OpenAsync();

            const string sql = "SELECT \"CourseId\", \"CourseName\" FROM \"Courses\" ORDER BY \"CourseName\";";
            await using var cmd = new NpgsqlCommand(sql, conn);
            await using var reader = await cmd.ExecuteReaderAsync();
            table.Load(reader);

            cboCourse.DataSource = table;
            cboCourse.DisplayMember = "CourseName";
            cboCourse.ValueMember = "CourseId";
            cboCourse.SelectedIndex = table.Rows.Count > 0 ? 0 : -1;

            if (table.Rows.Count == 0)
                MessageBox.Show("Chưa có khóa học trong bảng Courses.", "Thông báo");
        }
        catch (NpgsqlException ex)
        {
            MessageBox.Show("Không tải được danh sách khóa học. Hãy kiểm tra database và chuỗi kết nối.\n\nChi tiết: " + ex.Message,
                "Lỗi cơ sở dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private async void BtnRegister_Click(object? sender, EventArgs e)
    {
        errorProvider.Clear();
        bool valid = true;

        if (string.IsNullOrWhiteSpace(txtFullName.Text))
        {
            errorProvider.SetError(txtFullName, "Vui lòng nhập họ tên.");
            valid = false;
        }

        if (!mtxtPhone.MaskFull)
        {
            errorProvider.SetError(mtxtPhone, "Vui lòng nhập đủ số điện thoại.");
            valid = false;
        }

        if (cboCourse.SelectedValue is null || cboCourse.SelectedIndex < 0)
        {
            errorProvider.SetError(cboCourse, "Vui lòng chọn khóa học.");
            valid = false;
        }

        if (!valid) return;

        string gender = rdoMale.Checked ? "Nam" : "Nữ";
        var interests = new List<string>();
        if (chkProgramming.Checked) interests.Add("Lập trình");
        if (chkSports.Checked) interests.Add("Thể thao");
        if (chkMusic.Checked) interests.Add("Âm nhạc");
        string interestsText = interests.Count > 0 ? string.Join(", ", interests) : "Không chọn";
        string courseName = cboCourse.Text;
        int courseId = Convert.ToInt32(cboCourse.SelectedValue);
        string phone = mtxtPhone.Text;

        string summary =
            $"Họ và tên: {txtFullName.Text.Trim()}\n" +
            $"Số điện thoại: {phone}\n" +
            $"Ngày sinh: {dtpBirthDate.Value:dd/MM/yyyy}\n" +
            $"Giới tính: {gender}\n" +
            $"Khóa học: {courseName}\n" +
            $"Sở thích: {interestsText}";

        btnRegister.Enabled = false;
        try
        {
            await using var conn = Database.CreateConnection();
            await conn.OpenAsync();

            const string sql = """
                INSERT INTO "Registrations"
                    ("FullName", "Phone", "BirthDate", "Gender", "CourseId", "Interests")
                VALUES
                    (@fullName, @phone, @birthDate, @gender, @courseId, @interests);
                """;

            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("fullName", txtFullName.Text.Trim());
            cmd.Parameters.AddWithValue("phone", phone);
            cmd.Parameters.AddWithValue("birthDate", dtpBirthDate.Value.Date);
            cmd.Parameters.AddWithValue("gender", gender);
            cmd.Parameters.AddWithValue("courseId", courseId);
            cmd.Parameters.AddWithValue("interests", interestsText);
            await cmd.ExecuteNonQueryAsync();

            MessageBox.Show(summary + "\n\nĐã lưu đăng ký vào PostgreSQL.", "Thông tin đăng ký",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (NpgsqlException ex)
        {
            MessageBox.Show("Không lưu được đăng ký vào PostgreSQL.\n\nChi tiết: " + ex.Message,
                "Lỗi cơ sở dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            btnRegister.Enabled = true;
        }
    }
}
